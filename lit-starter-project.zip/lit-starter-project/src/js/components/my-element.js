import { LitElement } from 'lit';

class MyElement extends LitElement {}

customElements.define('my-element', MyElement);
